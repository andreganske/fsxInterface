Quadrature library for the Arduino.

UPDATED ,,, see below.

Installation ,,,
Just put the folder "Quadrature" into the "library" folder within the Arduino folder.

History ,,,
This library was made by Keith Neufeld of  
http://www.neufeld.newton.ks.us/electronics
http://www.neufeld.newton.ks.us/electronics/?p=248#more-248 
It was by far the best of all the one's I tried, how ever it did not work on the later Arduino IDE's.

Progress marches on and when version 1 of the Arduino IDE came out Kieth's library failed to 
work due to changes in the way the Arduino IDE compiled.
Along came Bill Holland and made a mod that enabled it to work on version 1 and 1.1
Bill's mod was further refined by me and packaged up to what you have here.
It will now work in 0022,  1, and 1.1 (Thats all I tried)

It is best to leave this readme file in the package as all the file names are the same as the old one.
Therefore the only way for a novice to tell that this is the new one ,, will be by this readme file.

Thanks to Keith for the original library and thanks also to Bill for the first mod.

Some demo's are included to help with interfacing rotary encoders into my Link2fs programs.
They are designed to work with "Link2fs_inOut".
They all work with this modified libray using Arduino IDE 0022 thru to the latest. (1.1)


In the one with "hold-down" in the name ,, it shows a different way to read the encode (code wise) and
also how to integrate the "hold-down-the-knob" and use the encoder to send a different code if it's held down.

None of these demo's are nessecary the best code but it steps it out in a pattern newbies should be 
able to pick up easily and blend into their code.   That is the whole idea.

UPDATE Aug 2013 ,,,,

IMPORTANT ,,,,,
The basic library is set up for a Uno ,,, to use on a Mega there is only one change to make ,,,,
All that needs doing is to open out the 'quadrature.h' file and edit the line '#define DIGITAL_PINS (14)'.  
Change the 14 to what ever pin no. is going to be your highest.(69 maybe)

Keiths library does half and full cycle encoders ,, there is however a another type on the block that is getting more
and more prevelent and that is a QUARTER CYCLE encoder. (One state change per click)
If your encoders are quarter cycle type then you dont need to use a library at all.
I have enclosed a demo called "quarter_cycle_encoder_demo" that has 2 different types of code showing how to do it.
DON'T  USE THE LIBRARY if you have quarter cycle encoders.

USE with the 'Link2sf_inOut" or the "Link2fs_Multi" ,,,,
These sample codes are written mainly for the 'inOut' program but all can be used in the 'inOut' prgram as well as the 'Multi' program.
The difference is small but important.

'InOut' does not require a Linefeed to be sent from the Arduino to the 'inOut' program where the 'Multi' needs a linefeed at the end of the 
data burst or it may not work.

Simply ,,,,  'inOut' code will be like this ,,,,
blah blah blah Serial.print(blah);

where-as the 'Multi's code would be ,,,,
blah blah blah Serial.println(blah);   //Note the 'ln' at the end of print.
There is one exception in the 'Multi' and that is for "keys" ,,,  where bits of the complete data burst are sent seperately.
ie ,,
Serial.print ("D"); 
    if (pinNo < 10) Serial.print ("0");
    Serial.print (pinNo);
    Serial.print (pinStateSTR);
     }
Now in the above example ,,, only the final Serial.print needs changed.
So ,,, the correct code for the "keys" bit in the "multi" would be ,,,,
Serial.print ("D"); 
    if (pinNo < 10) Serial.print ("0");
    Serial.print (pinNo);
    Serial.println (pinStateSTR);
     }

Just study the PDE/INO's ,,, you will see the changes and it will all come clear. :)

In reality ,, just one encoders not enough as you continue to build.  The way to put as many in there as you like is to make more "Quad"s !!!!
Main pointers ,,,,
Quadrature quad1(8, 9);
Quadrature quad2(10, 11);
Quadrature quad3(12, 14);
Quadrature quad4(15, 16);
Serial.println(quad1.position());
Serial.println(quad2.position());
Serial.println(quad3.position());
Serial.println(quad4.position()); etc etc 

Add as many as you want and just manipulate the "quads" for each purpose.
(Remember to avoid pin 13 on the Arduino unless you have made the appropriate changes.)


Hope you have fun with it ,,, Jim

Jim NZ
Jimspage.co.nz
5-8-13









